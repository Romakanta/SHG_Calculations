#!/bin/bash -l
#SBATCH --job-name="B2Te3"	# name of the Job
#SBATCH --output="log-file"	# IOf you want to explicitly direct the output to a file. The default is slurm-jobid.out
#SBATCH --partition=parallel	# Name of the queue
#SBATCH --time 00-02:00:00	# Time limit (days-hour:minutes:seconds)
#SBATCH --nodes=1		# Number of nodes requested
#SBATCH --ntasks-per-node=48	# Number of cores per node
#SBATCH --account=trevor42	# Account
#SBATCH --export=ALL

#module load purge
module load abinit/9.6.2
export OMP_NUM_THREADS=1

#mpirun -np 48 /data/apps/extern/abinit/9.6.2/bin/abinit mono_B2Te3_shg.abi > output_shg
mpirun -np 48 /data/apps/extern/abinit/9.6.2/bin/optic mono_B2Te3_optic.abi > output_optic
